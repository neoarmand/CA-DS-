package my.myca;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aldoseckoflores
 */
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceListener;
import javax.jmdns.ServiceInfo;
import java.io.IOException;

public class ServiceDiscovery {

    public static void main(String[] args) {
        try {
            JmDNS jmdns = JmDNS.create();
            
            // Service listener to detect the available services
            ServiceListener listener = new ServiceListener() {
                @Override
                public void serviceAdded(ServiceEvent event) {
                    // Service added
                    ServiceInfo info = event.getInfo();
                    System.out.println("Service added: " + info);
                }

                @Override
                public void serviceRemoved(ServiceEvent event) {
                    // Service removed
                    ServiceInfo info = event.getInfo();
                    System.out.println("Service removed: " + info);
                }

                @Override
                public void serviceResolved(ServiceEvent event) {
                    // Service resolved (IP and port available)
                    ServiceInfo info = event.getInfo();
                    System.out.println("Service resolved: " + info);
                }
            };

            // Listen for services of type "_grpc._tcp.local."
            jmdns.addServiceListener("_grpc._tcp.local.", listener);

            // Keep the program running
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

