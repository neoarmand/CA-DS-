/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.myca;

/**
 *
 * @author aldoseckoflores
 */
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;
import java.io.IOException;

public class JmDnsServiceRegistration {

    private static JmDNS jmdns;

    public static void registerService(String serviceName, String serviceType, int port) throws IOException {
        if (jmdns == null) {
            try {
                jmdns = JmDNS.create();
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        }

        ServiceInfo serviceInfo = ServiceInfo.create(serviceType, serviceName, port, "MyCA gRPC service");
        jmdns.registerService(serviceInfo);

        System.out.println("Registered service: " + serviceName + " at port " + port);
    }

    public static void unregisterService() {
        if (jmdns != null) {
            jmdns.unregisterAllServices();
            try {
                jmdns.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            jmdns = null;

            System.out.println("Unregistered services");
        }
    }
}



