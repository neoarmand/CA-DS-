/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.myca;

/**
 *
 * @author aldoseckoflores
 */
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import java.io.IOException;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;

public class MyCAServiceServer {

    public static void main(String[] args) throws IOException, InterruptedException {
        MyCAServiceServer server = new MyCAServiceServer();
        server.start();
        server.blockUntilShutdown();
    }

    private final int port = 50051;
    private Server grpcServer;

    private void start() throws IOException {
        grpcServer = ServerBuilder.forPort(port)
                .addService(new EnvironmentalControl1Impl())
                .addService(new LightingManagement2Impl())
                .addService(new EnergyManagement3Impl())
                .build()
                .start();

        System.out.println("Server started, listening on port " + port);

        // Register gRPC service with JmDNS
        try {
            JmDnsServiceRegistration.registerService("MyCAService", "_myca._tcp.local", port);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Runtime.getRuntime().addShutdownHook(new Thread(this::stop));
    }

    private void stop() {
        if (grpcServer != null) {
            grpcServer.shutdown();
            JmDnsServiceRegistration.unregisterService();
        }
    }

    private void blockUntilShutdown() throws InterruptedException {
        if (grpcServer != null) {
            grpcServer.awaitTermination();
        }
    }

    private class EnvironmentalControl1Impl extends EnvironmentalControl1Grpc.EnvironmentalControl1ImplBase {

        @Override
        public void function1Service1(MsgRequest request, StreamObserver<MsgReply> responseObserver) {
            String responseMessage = "Hello, " + request.getMessage();
            MsgReply response = MsgReply.newBuilder().setMessage(responseMessage).build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }
    }

    private class LightingManagement2Impl extends LightingManagement2Grpc.LightingManagement2ImplBase {

        @Override
        public void function1Service2(MsgRequest request, StreamObserver<MsgReply> responseObserver) {
            for (int i = 0; i < 5; i++) {
                String responseMessage = "Response for: " + request.getMessage();
                MsgReply response = MsgReply.newBuilder().setMessage(responseMessage).build();
                responseObserver.onNext(response);
            }
            responseObserver.onCompleted();
        }

        @Override
        public StreamObserver<MsgRequest> function2Service2(StreamObserver<MsgReply> responseObserver) {
            return new StreamObserver<MsgRequest>() {
                private final StringBuilder messages = new StringBuilder();

                @Override
                public void onNext(MsgRequest value) {
                    messages.append(value.getMessage()).append(", ");
                }

                @Override
                public void onError(Throwable t) {
                    // Handle error if needed
                }

                @Override
                public void onCompleted() {
                    String responseMessage = "Received messages: " + messages.toString();
                    MsgReply response = MsgReply.newBuilder().setMessage(responseMessage).build();
                    responseObserver.onNext(response);
                    responseObserver.onCompleted();
                }
            };
        }
    }

    private class EnergyManagement3Impl extends EnergyManagement3Grpc.EnergyManagement3ImplBase {

        @Override
        public StreamObserver<MsgRequest> function1Service3(StreamObserver<MsgReply> responseObserver) {
            return new StreamObserver<MsgRequest>() {
                @Override
                public void onNext(MsgRequest value) {
                    String responseMessage = "Received: " + value.getMessage();
                    MsgReply response = MsgReply.newBuilder().setMessage(responseMessage).build();
                    responseObserver.onNext(response);
                }

                @Override
                public void onError(Throwable t) {
                    // Handle error if needed
                }

                @Override
                public void onCompleted() {
                    responseObserver.onCompleted();
                }
            };
        }
    }
}
