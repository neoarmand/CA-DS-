/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.myca;

/**
 *
 * @author aldoseckoflores
 */


import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

public class MyCAServiceClient {

    public static void main(String[] args) {
        MyCAServiceClient client = new MyCAServiceClient();
        client.run();
    }

    private final String host = "localhost"; // Replace with your server's hostname or IP
    private final int port = 50051; // Replace with your server's port

    private void run() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress(host, port)
                .usePlaintext()  // Insecure mode for simplicity
                .build();

        try {
            // Create stubs for the three services
            EnvironmentalControl1Grpc.EnvironmentalControl1BlockingStub ec1Stub =
                    EnvironmentalControl1Grpc.newBlockingStub(channel);

            LightingManagement2Grpc.LightingManagement2BlockingStub lm2Stub =
                    LightingManagement2Grpc.newBlockingStub(channel);

            EnergyManagement3Grpc.EnergyManagement3Stub em3Stub =
                    EnergyManagement3Grpc.newStub(channel);

            // Call the services
            callEnvironmentalControl1Service(ec1Stub);
            callLightingManagement2Service(lm2Stub);
            callEnergyManagement3Service(em3Stub);
        } finally {
            channel.shutdown();
        }
    }

    private void callEnvironmentalControl1Service(EnvironmentalControl1Grpc.EnvironmentalControl1BlockingStub stub) {
        MsgRequest request = MsgRequest.newBuilder().setMessage("Environmental Control 1").build();
        MsgReply response = stub.function1Service1(request);
        System.out.println("EnvironmentalControl1 response: " + response.getMessage());
    }

  private void callLightingManagement2Service(LightingManagement2Grpc.LightingManagement2BlockingStub stub) {
    MsgRequest request = MsgRequest.newBuilder().setMessage("Lighting Management 2").build();
    
    // Invoking the server streaming RPC method
    stub.function1Service2(request)
        .forEachRemaining(response -> {
            System.out.println("Received response: " + response.getMessage());
        });
}



  private void callEnergyManagement3Service(EnergyManagement3Grpc.EnergyManagement3Stub stub) {
        StreamObserver<MsgReply> responseObserver = new StreamObserver<MsgReply>() {
            @Override
            public void onNext(MsgReply response) {
                System.out.println("EnergyManagement3 response: " + response.getMessage());
            }

            @Override
            public void onError(Throwable t) {
                t.printStackTrace();
            }

            @Override
            public void onCompleted() {
                System.out.println("EnergyManagement3 completed");
            }
        };

        StreamObserver<MsgRequest> requestObserver = stub.function1Service3(responseObserver);
        try {
            requestObserver.onNext(MsgRequest.newBuilder().setMessage("Message 1").build());
            requestObserver.onNext(MsgRequest.newBuilder().setMessage("Message 2").build());
            requestObserver.onNext(MsgRequest.newBuilder().setMessage("Message 3").build());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            requestObserver.onCompleted();
            System.out.println("EnergyManagement3 completed");
        }
    }
}

