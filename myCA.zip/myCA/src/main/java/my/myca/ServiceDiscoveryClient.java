/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.myca;

/**
 *
 * @author aldoseckoflores
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.jmdns.JmDNS;
import javax.jmdns.ServiceInfo;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import my.myca.*;

public class ServiceDiscoveryClient extends JFrame {
    private JList<String> serviceList;
    private JTextArea responseArea;
    private JButton callButton;

    private ManagedChannel channel;
    private EnvironmentalControl1Grpc.EnvironmentalControl1BlockingStub ec1Stub;
    private LightingManagement2Grpc.LightingManagement2BlockingStub lm2Stub;
    private EnergyManagement3Grpc.EnergyManagement3BlockingStub em3Stub;

    public ServiceDiscoveryClient() {
        setTitle("Service Discovery Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        serviceList = new JList<>();
        responseArea = new JTextArea(15, 50);
        callButton = new JButton("Call Service");

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(new JScrollPane(serviceList), BorderLayout.WEST);
        mainPanel.add(new JScrollPane(responseArea), BorderLayout.CENTER);
        mainPanel.add(callButton, BorderLayout.SOUTH);

        add(mainPanel);

        initGrpcStubs();
        initServiceDiscovery();

        callButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                callSelectedService();
            }
        });
    }

    private void initGrpcStubs() {
        channel = ManagedChannelBuilder.forAddress("localhost", 50051)
                .usePlaintext()
                .build();

        ec1Stub = EnvironmentalControl1Grpc.newBlockingStub(channel);
        lm2Stub = LightingManagement2Grpc.newBlockingStub(channel);
        em3Stub = EnergyManagement3Grpc.newBlockingStub(channel);
    }

    private void initServiceDiscovery() {
        try {
            JmDNS jmdns = JmDNS.create();

            // Service type should match what the server is registered with
            ServiceInfo[] services = jmdns.list("_http._tcp.local.");

            DefaultListModel<String> listModel = new DefaultListModel<>();
            for (ServiceInfo service : services) {
                listModel.addElement(service.getName());
            }

            serviceList.setModel(listModel);

            jmdns.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void callSelectedService() {
        String selectedService = serviceList.getSelectedValue();
        if (selectedService == null) {
            responseArea.setText("Please select a service.");
            return;
        }

        String responseText = "";

        switch (selectedService) {
            case "EnvironmentalControl1":
                MsgRequest ec1Request = MsgRequest.newBuilder().setMessage("Environmental Control 1").build();
                MsgReply ec1Response = ec1Stub.function1Service1(ec1Request);
                responseText = "EnvironmentalControl1 response: " + ec1Response.getMessage();
                break;

            case "LightingManagement2":
                MsgRequest lm2Request = MsgRequest.newBuilder().setMessage("Lighting Management 2").build();
                MsgReply lm2Response = lm2Stub.function1Service2(lm2Request);
                responseText = "LightingManagement2 response: " + lm2Response.getMessage();
                break;

            case "EnergyManagement3":
                MsgRequest em3Request = MsgRequest.newBuilder().setMessage("Energy Management 3").build();
                MsgReply em3Response = em3Stub.function1Service3(em3Request);
                responseText = "EnergyManagement3 response: " + em3Response.getMessage();
                break;
        }

        responseArea.setText(responseText);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ServiceDiscoveryClient().setVisible(true);
            }
        });
    }
}


